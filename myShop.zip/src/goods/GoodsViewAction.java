package goods;

import java.net.URLEncoder;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import controller.Action;
import controller.ActionForward;
import dao.GoodsDAO;
import dto.Goods;

public class GoodsViewAction implements Action {
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
		ActionForward forward = new ActionForward();
		GoodsDAO goodsDAO = new GoodsDAO();
		String id = request.getParameter("goods_num");
		Goods goods = goodsDAO.getGoods(id);
		
		
		Cookie cookie = new Cookie("image"+id, URLEncoder.encode(goods.getGoodsImage()));
		cookie.setMaxAge(60*60*24);
		response.addCookie(cookie);
		request.setAttribute("goods", goods);
		forward.setRedirect(false);
		forward.setPath("./Goods/goodsView.jsp");
		
		return forward;
		
	}
	
}