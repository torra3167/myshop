package goods;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import biz.CartBiz;
import controller.Action;
import controller.ActionForward;

public class GoodsCartQtyUpAction implements Action{
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response)throws Exception {
		ActionForward forward = new ActionForward();
		String name = request.getParameter("name");
		
		CartBiz cartBiz = new CartBiz();
		cartBiz.upCartQty(request,name);
		
		forward.setRedirect(true);
		forward.setPath("./goodsCartList.goods");
		
		return forward;
	}

}
