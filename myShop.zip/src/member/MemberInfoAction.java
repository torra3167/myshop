package member;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import controller.Action;
import controller.ActionForward;
import dao.MemberDAO;
import dto.MemberBean;

public class MemberInfoAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("utf-8");

		ActionForward forward = new ActionForward();
		String id = request.getParameter("id");
		MemberDAO dao = new MemberDAO();
		MemberBean dto = new MemberBean();

		dto = dao.info(id);
		if (dto == null) {
			System.out.println("INFO����");
			forward = null;
		} else {
			request.setAttribute("member", dto);
			forward.setRedirect(false);
			forward.setPath("MemberView/member_info.jsp");
		}

		return forward;
	}

}
