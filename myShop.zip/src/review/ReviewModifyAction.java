package review;

import java.io.PrintWriter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import controller.Action;
import controller.ActionForward;
import dao.ReviewDAO;
import dto.ReviewBean;

public class ReviewModifyAction implements Action {

	public ActionForward execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
		
		ActionForward forward = new ActionForward();
		ReviewDAO reviewdao = new ReviewDAO();
		ReviewBean reviewdata = new ReviewBean();
		request.setCharacterEncoding("utf-8");
		boolean usercheck = false;
		usercheck = reviewdao.isReviewWriter(Integer.parseInt(request.getParameter("REVIEW_NUM")),
				request.getParameter("REVIEW_PASS"));
		if (usercheck == false) {
			response.setContentType("text/html;charset=utf-8");
			PrintWriter out = response.getWriter();
			out.println("<script>");
			out.println("alert('수정할 권한이 없습니다.');");
			out.println("location.href='./ReviewList.review';");
			out.println("</script>");
			out.close();
			return null;
		}
		reviewdata.setReviewNum(Integer.parseInt(request.getParameter("REVIEW_NUM")));
		reviewdata.setReviewSubject(request.getParameter("REVIEW_SUBJECT"));
		reviewdata.setReviewContent(request.getParameter("REVIEW_CONTENT"));
		int result = reviewdao.reviewModify(reviewdata);
		forward.setRedirect(true);
		forward.setPath("./ReviewDetailAction.review?num=" + reviewdata.getReviewNum());

		return forward;
	}

}
