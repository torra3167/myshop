package goods;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import controller.Action;
import controller.ActionForward;
import dao.GoodsDAO;
import dto.Goods;
import biz.CartBiz;

public class GoodsCartAddAction implements Action {
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
		ActionForward forward = new ActionForward();
		String id = request.getParameter("goods_num");
		GoodsDAO dao = new GoodsDAO();
		Goods goods = dao.getGoods(id);
		
		//session에 상품 등록 하기 위해 만든다.
		CartBiz cartBiz = new CartBiz();
		cartBiz.addCart(request,goods);
		forward.setRedirect(true);
		forward.setPath("goodsCartList.goods");
		
		return forward;
	}

}
