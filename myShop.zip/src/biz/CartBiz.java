package biz;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import dto.Goods;


public class CartBiz { // 상품정보를 session에 저장하기 위한 클래스
	public void addCart(HttpServletRequest request, Goods goods) {
		HttpSession session = request.getSession();
		
		List cartList = (List)session.getAttribute("cartList");
		if(cartList==null) {
			cartList = new ArrayList();
		}
		// 상품정보 및 수량을 임시로 저장하기 위한 클래스 
		Cart cart = null;
		
		// 새로운 상품인지 아닌지 확인하기 위한 변수
		boolean newCart = true;
		// session에 선택한 상품이 존재하는지 확인
		for(int i=0; i<cartList.size(); i++) {
			cart = (Cart)cartList.get(i);
			if(goods.getGoodsName().equals(cart.getName())) {
				newCart = false;
				cart.setQty(cart.getQty()+1);
			}
		}
		if(newCart) {
			cart = new Cart();
			cart.setImage(goods.getGoodsImage());
			cart.setName(goods.getGoodsName());
			cart.setPrice(goods.getGoodsPrice());
			cart.setQty(1);
			cartList.add(cart);
		}
		
		session.setAttribute("cartList", cartList);
	}

	public void upCartQty(HttpServletRequest request, String name) {
		HttpSession session = request.getSession();
		List cartList = (List)session.getAttribute("cartList");
		for(int i=0; i<cartList.size();i++) {
			Cart cart = (Cart)cartList.get(i);
			if(cart.getName().equals(name)) {
				cart.setQty(cart.getQty()+1);
			}
		}
		
	}
	public void downCartQty(HttpServletRequest request, String name) {
		HttpSession session = request.getSession();
		List cartList = (List)session.getAttribute("cartList");
		for(int i=0; i<cartList.size();i++) {
			Cart cart = (Cart)cartList.get(i);
			if(cart.getName().equals(name)) {
				cart.setQty(cart.getQty()-1);
			}
		}
		
	}

	
	public void removeCartItem(HttpServletRequest request, String[] names) {
		HttpSession session = request.getSession();
		List list = (List)session.getAttribute("cartList");
		for(int i=0; i<names.length; i++) {
			for(int j=0; j<list.size();j++) {
				Cart cart = (Cart)list.get(j);
				if(names[i].equals(cart.getName())) {
					list.remove(list.get(j));
				}
			}
		}
		
	}
}