package goods;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import biz.CartBiz;
import controller.Action;
import controller.ActionForward;

public class GoodsCartRemoveAction implements Action {
public ActionForward execute(HttpServletRequest request, HttpServletResponse response) throws Exception{
		
		request.setCharacterEncoding("utf-8");
		String [] names = request.getParameterValues("delete");
		CartBiz cartBiz = new CartBiz();
		cartBiz.removeCartItem(request, names);
		
		ActionForward forward = new ActionForward();
		forward.setRedirect(true);
		forward.setPath("./goodsCartList.goods");
		
		return forward;
	}

}
