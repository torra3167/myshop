package member;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import controller.Action;
import controller.ActionForward;

public class MemberLogoutAction implements Action {


		@Override
		public ActionForward execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
			// TODO Auto-generated method stub
			ActionForward forward = new ActionForward();
			HttpSession session = request.getSession();
			String id = (String)session.getAttribute("ID");
			request.setCharacterEncoding("utf-8");

			if(id == null) {
				System.out.println("���Ǿ��̵��� ����");
				
				
			} else {
				session.invalidate();
				System.out.println("�α׾ƿ�����");
				
				
			}
			forward.setRedirect(true);
			forward.setPath("MemberLogin.me");
			return forward;
			
		}
}


