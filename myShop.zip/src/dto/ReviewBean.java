package dto;

import java.io.Serializable;
import java.util.Date;

public class ReviewBean implements Serializable{

	private int reviewNum;
	private String reviewName;
	private String reviewPw;
	private String reviewSubject;
	private String reviewContent;
	private String reviewFile;
	private int reviewReRef;
	private int reviewReLev;
	private int reviewReSeq;
	private int reviewReadcount;
	private Date reviewDate;

	public int getReviewNum() {
		return reviewNum;
	}

	public void setReviewNum(int reviewNum) {
		this.reviewNum = reviewNum;
	}

	public String getReviewName() {
		return reviewName;
	}

	public void setReviewName(String reviewName) {
		this.reviewName = reviewName;
	}

	public String getReviewPw() {
		return reviewPw;
	}

	public void setReviewPw(String reviewPw) {
		this.reviewPw = reviewPw;
	}

	public String getReviewSubject() {
		return reviewSubject;
	}

	public void setReviewSubject(String reviewSubject) {
		this.reviewSubject = reviewSubject;
	}

	public String getReviewContent() {
		return reviewContent;
	}

	public void setReviewContent(String reviewContent) {
		this.reviewContent = reviewContent;
	}

	public String getReviewFile() {
		return reviewFile;
	}

	public void setReviewFile(String reviewFile) {
		this.reviewFile = reviewFile;
	}

	public int getReviewReRef() {
		return reviewReRef;
	}

	public void setReviewReRef(int reviewReRef) {
		this.reviewReRef = reviewReRef;
	}

	public int getReviewReLev() {
		return reviewReLev;
	}

	public void setReviewReLev(int reviewReLev) {
		this.reviewReLev = reviewReLev;
	}

	public int getReviewReSeq() {
		return reviewReSeq;
	}

	public void setReviewReSeq(int reviewReSeq) {
		this.reviewReSeq = reviewReSeq;
	}

	public int getReviewReadcount() {
		return reviewReadcount;
	}

	public void setReviewReadcount(int reviewReadcount) {
		this.reviewReadcount = reviewReadcount;
	}

	public Date getReviewDate() {
		return reviewDate;
	}

	public void setReviewDate(Date reviewDate) {
		this.reviewDate = reviewDate;
	}

}
