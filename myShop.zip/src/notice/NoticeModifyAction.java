package notice;

import java.io.PrintWriter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import controller.Action;
import controller.ActionForward;
import dao.NoticeDAO;
import dto.NoticeBean;

public class NoticeModifyAction implements Action {

	public ActionForward execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
		ActionForward forward = new ActionForward();
		NoticeDAO noticedao = new NoticeDAO();
		NoticeBean noticedata = new NoticeBean();
		request.setCharacterEncoding("utf-8");
		boolean usercheck = false;
		usercheck = noticedao.isNoticeWriter(Integer.parseInt(request.getParameter("NOTICE_NUM")),
				request.getParameter("NOTICE_PASS"));
		if (usercheck == false) {
			response.setContentType("text/html;charset=utf-8");
			PrintWriter out = response.getWriter();
			out.println("<script>");
			out.println("alert('수정할 권한이 없습니다.');");
			out.println("location.href='./NoticeList.notice';");
			out.println("</script>");
			out.close();
			return null;
		}
		noticedata.setNoticeNum(Integer.parseInt(request.getParameter("NOTICE_NUM")));
		noticedata.setNoticeSubject(request.getParameter("NOTICE_SUBJECT"));
		noticedata.setNoticeContent(request.getParameter("NOTICE_CONTENT"));
		int result = noticedao.noticeModify(noticedata);
		forward.setRedirect(true);
		forward.setPath("./NoticeDetailAction.notice?num=" + noticedata.getNoticeNum());

		return forward;
	}

}
