package notice;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import controller.Action;
import controller.ActionForward;
import dao.NoticeDAO;
public class NoticeListAction implements Action {

	ActionForward forward = null;

	public ActionForward execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
		NoticeDAO noticedao = new NoticeDAO();
		request.setCharacterEncoding("utf-8");

		List noticelist = new ArrayList();

		int page = 1;
		int limit = 10;

		if (request.getParameter("page") != null) {
			page = Integer.parseInt(request.getParameter("page"));
		}

		int listcount = noticedao.getListCount();
		noticelist = noticedao.getNoticeList(page, limit);
		int maxpage = (int) ((double) listcount / limit + 0.95);

		int startpage = ((int) ((double) page / 10 + 0.9) - 1) * 10 + 1;
		int endpage = startpage + 10 - 1;
		if (endpage > maxpage)
			endpage = maxpage;

		request.setAttribute("page", page); // 현재 페이지 수
		request.setAttribute("maxpage", maxpage);
		request.setAttribute("startpage", startpage);
		request.setAttribute("endpage", endpage);
		request.setAttribute("listcount", listcount);
		request.setAttribute("noticelist", noticelist);

		forward = new ActionForward();
		forward.setRedirect(false);
		forward.setPath("./NoticeView/notice_board_list.jsp");

		return forward;
	}
}
