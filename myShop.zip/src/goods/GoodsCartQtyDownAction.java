package goods;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import biz.CartBiz;
import controller.Action;
import controller.ActionForward;

public class GoodsCartQtyDownAction implements Action{
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
		String name = request.getParameter("name");
		CartBiz cartBiz = new CartBiz();
		cartBiz.downCartQty(request,name);
				
		ActionForward forward = new ActionForward();
		forward.setRedirect(true);
		forward.setPath("./goodsCartList.goods");
		return forward;
	}
	
}
