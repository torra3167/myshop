package controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import review.ReviewListAction;

public class PageFrontController extends javax.servlet.http.HttpServlet implements javax.servlet.Servlet {
	
	
	protected void doProcess(HttpServletRequest request, HttpServletResponse response) {
		String requestURI = request.getRequestURI();
		String contextPath = request.getContextPath();
		
		String cmd = requestURI.substring(contextPath.length());
		Action action = null;
		ActionForward forward = null;
		
		
		if(cmd.equals("/Main.shop")) {
			if(request.getParameter("num").equals("1")) {
				action = new ReviewListAction();
				try {
					forward = action.execute(request, response);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}else if() {
				
			}
			
			forward = new ActionForward();
			forward.setPath("home/index.jsp");
			forward.setRedirect(false);
			
		}
		
		
		
		
		if(forward != null) {
			if(forward.isRedirect()) {
				try {
					response.sendRedirect(forward.getPath());
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			} else {
				try {
					RequestDispatcher rdp = request.getRequestDispatcher(forward.getPath());
					rdp.forward(request, response);
				} catch (ServletException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) {
		System.out.println("POST");
		doProcess(request, response);
	}
	protected void doGet(HttpServletRequest request, HttpServletResponse response) {
		System.out.println("GET");
		doProcess(request, response);
	}
}
