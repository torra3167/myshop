package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import dto.NoticeBean;

public class NoticeDAO {

	Connection conn = null;
	Connection con = null;
	PreparedStatement pstmt = null;
	String sql = null;
	ResultSet rs = null;

	public Connection getConnection() throws Exception {
		String driver = "oracle.jdbc.driver.OracleDriver";
		String url = "jdbc:oracle:thin:@localhost:1521:XE";
		Class.forName(driver);
		conn = DriverManager.getConnection(url, "smrit", "oracle");
		return conn;
	}

	public int noticeInsert(NoticeBean noticedata) {
		int i = 0;
		int num = 0;
		try {
			con = getConnection();
			sql = "select max(notice_num) from notice";
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			if (rs.next()) {
				num = rs.getInt(1) + 1;
			} else {
				num = 1;
			}
			sql = "insert into notice(notice_num,notice_subject,notice_content,notice_readcount,notice_file,notice_pw,notice_date)"
					+ " values(?,?,?,?,?,?,sysdate)";
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, num);
			pstmt.setString(2, noticedata.getNoticeSubject());
			pstmt.setString(3, noticedata.getNoticeContent());
			pstmt.setInt(4, noticedata.getNoticeReadcount());
			pstmt.setString(5, noticedata.getNoticeFile());
			pstmt.setString(6, noticedata.getNoticePw());
			i = pstmt.executeUpdate();
			System.out.println(i + "insert");
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (rs != null)
				try {
					rs.close();
				} catch (SQLException ex) {
				}
			if (pstmt != null)
				try {
					pstmt.close();
				} catch (SQLException ex) {
				}
			if (con != null)
				try {
					con.close();
				} catch (SQLException ex) {
				}
		}
		return i;
	}

	public int getListCount() {
		int x = 0;
		try {
			con = getConnection();
			pstmt = con.prepareStatement("select count(*) from notice");
			rs = pstmt.executeQuery();
			if (rs.next()) {
				x = rs.getInt(1);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (rs != null)
				try {
					rs.close();
				} catch (SQLException ex) {
				}
			if (pstmt != null)
				try {
					pstmt.close();
				} catch (SQLException ex) {
				}
			if (con != null)
				try {
					con.close();
				} catch (SQLException ex) {
				}
		}
		return x;
	}

	public List getNoticeList(int page, int limit) {
		List list = new ArrayList();
		try {
			con = getConnection();
			sql = "select * from "
					+ "(select rownum rnum,notice_num,notice_subject,notice_content,notice_readcount,notice_date,notice_file,notice_pw"
					+ "    from (select * from notice order by notice_num DESC)" + ")" + "where rnum >=? and  rnum <= ?";
			int startRow = (page - 1) * limit + 1;
			int endRow = startRow + limit - 1;
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, startRow);
			pstmt.setInt(2, endRow);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				NoticeBean noticedata = new NoticeBean();
				noticedata.setNoticeNum(rs.getInt("notice_Num"));
				noticedata.setNoticeSubject(rs.getString("notice_subject"));
				noticedata.setNoticeContent(rs.getString("notice_content"));
				noticedata.setNoticeReadcount(rs.getInt("notice_readcount"));
				noticedata.setNoticeDate(rs.getDate("notice_date"));
				noticedata.setNoticeFile(rs.getString("notice_file"));
				noticedata.setNoticePw(rs.getString("notice_pw"));
				list.add(noticedata);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (rs != null)
				try {
					rs.close();
				} catch (SQLException ex) {
				}
			if (pstmt != null)
				try {
					pstmt.close();
				} catch (SQLException ex) {
				}
			if (con != null)
				try {
					con.close();
				} catch (SQLException ex) {
				}
		}
		return list;
	}

	public NoticeBean getDetail(int num) {
		NoticeBean noticedata = null;
		try {
			con = getConnection();
			sql = "update notice set notice_readcount=notice_readcount+1 where notice_num=?";
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, num);
			int result = pstmt.executeUpdate();
			System.out.println(result + "Detail update");
			sql = "select * from notice where notice_num=?";
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, num);
			rs = pstmt.executeQuery();
			if (rs.next()) {
				noticedata = new NoticeBean();
				noticedata.setNoticeNum(rs.getInt("notice_Num"));
				noticedata.setNoticeSubject(rs.getString("notice_Subject"));
				noticedata.setNoticeContent(rs.getString("notice_Content"));
				noticedata.setNoticeReadcount(rs.getInt("notice_Readcount"));
				noticedata.setNoticeDate(rs.getDate("notice_Date"));
				noticedata.setNoticeFile(rs.getString("notice_File"));
				noticedata.setNoticePw(rs.getString("notice_Pw"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (rs != null)
				try {
					rs.close();
				} catch (SQLException ex) {
				}
			if (pstmt != null)
				try {
					pstmt.close();
				} catch (SQLException ex) {
				}
			if (con != null)
				try {
					con.close();
				} catch (SQLException ex) {
				}
		}
		return noticedata;
	}

	public boolean isNoticeWriter(int num,String pw) {
		try {
			sql = "select notice_pw from notice where notice_num =?";
			con = getConnection();
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, num);
			rs = pstmt.executeQuery();
			rs.next();
			if (pw.equals(rs.getString(1))) {
				return true;
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (rs != null)
				try {
					rs.close();
				} catch (SQLException ex) {
				}
			if (pstmt != null)
				try {
					pstmt.close();
				} catch (SQLException ex) {
				}
			if (con != null)
				try {
					con.close();
				} catch (SQLException ex) {
				}
		}
		return false;
	}

	public int noticeModify(NoticeBean modifynotice) {
		int result = 0;
		sql = "update notice set notice_subject=?,notice_content=? where notice_num=?";
		try {
			con = getConnection();
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, modifynotice.getNoticeSubject());
			pstmt.setString(2, modifynotice.getNoticeContent());
			pstmt.setInt(3, modifynotice.getNoticeNum());
			result = pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (rs != null)
				try {
					rs.close();
				} catch (SQLException ex) {
				}
			if (pstmt != null)
				try {
					pstmt.close();
				} catch (SQLException ex) {
				}
			if (con != null)
				try {
					con.close();
				} catch (SQLException ex) {
				}
		}
		return result;
	}

	public int noticeDelete(int num) {
		int result = 0;
		sql = "delete from notice where notice_num=?";
		try {
			con = getConnection();
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, num);
			result = pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (pstmt != null)
				try {
					pstmt.close();
				} catch (SQLException ex) {
				}
			if (con != null)
				try {
					con.close();
				} catch (SQLException ex) {
				}
		}
		return result;
	}
}
