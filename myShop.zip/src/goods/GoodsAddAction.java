package goods;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.oreilly.servlet.MultipartRequest;
import com.oreilly.servlet.multipart.DefaultFileRenamePolicy;

import controller.Action;
import controller.ActionForward;
import dao.GoodsDAO;
import dto.Goods;

public class GoodsAddAction implements Action {
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
		ActionForward forward = new ActionForward();
		GoodsDAO dao = new GoodsDAO();
		Goods Goods = new Goods();
		String realFolder = request.getRealPath("goodsUpload");
		int fileSize = 5*1024*1024;
		MultipartRequest multi = null;
		multi = new MultipartRequest(request, realFolder, fileSize, "UTF-8", new DefaultFileRenamePolicy());
		Goods.setGoodsKind(multi.getParameter("goodsKind"));
		Goods.setGoodsName(multi.getParameter("goodsName"));
		Goods.setGoodsPrice(Integer.parseInt(multi.getParameter("goodsPrice")));
		Goods.setGoodsImage(multi.getFilesystemName((String)multi.getFileNames().nextElement()));
		Goods.setGoodsCountry(multi.getParameter("goodsCountry"));
		Goods.setGoodsSize(multi.getParameter("goodsSize"));
		Goods.setGoodsColor(multi.getParameter("goodsColor"));
		Goods.setGoodsContent(multi.getParameter("goodsContent"));
		
		int i = dao.goodsInsert(Goods);
		
		if(i>0) {
			System.out.println("저장됨");
		} else System.out.println("저장 실패");
		forward.setRedirect(true);
		forward.setPath("./goodsList.goods");
		request.setAttribute("page", "../MemberView/joinForm");
		return forward;
	}

}

