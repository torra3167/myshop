package notice;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.NoticeDAO;
import dto.NoticeBean;
import controller.Action;
import controller.ActionForward;

public class NoticeModifyView implements Action {

	public ActionForward execute(HttpServletRequest request, HttpServletResponse response) throws Exception {

		request.setCharacterEncoding("utf-8");

		ActionForward forward = new ActionForward();
		NoticeDAO noticedao = new NoticeDAO();
		NoticeBean noticedata = new NoticeBean();
		int num = Integer.parseInt(request.getParameter("num"));
		noticedata = noticedao.getDetail(num);
		System.out.println("수정상세보기");
		request.setAttribute("noticedata", noticedata);
		forward.setRedirect(false);
		forward.setPath("./NoticeView/notice_board_modify.jsp");
		return forward;
	}
}
