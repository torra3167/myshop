package member;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import controller.Action;
import controller.ActionForward;
import dao.MemberDAO;
import dto.MemberBean;

public class MemberUpdateAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
		// TODO Auto-generated method stub
		ActionForward forward = new ActionForward();
		request.setCharacterEncoding("utf-8");

		MemberBean dto = new MemberBean();
		MemberDAO dao = new MemberDAO();
		HttpSession session = request.getSession();
		String id = (String) session.getAttribute("ID");
		dto = dao.info(id);
		if (dto == null) {
			System.out.println("ȸ�������ҷ����� ����");
			forward = null;
		} else {
			
			
			
			
			
			request.setAttribute("member", dto);
			forward.setRedirect(false);
			forward.setPath("MemberView/member_info.jsp");
		}

		return forward;
	}

}
