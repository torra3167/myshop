package notice;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.NoticeDAO;
import dto.NoticeBean;
import controller.Action;
import controller.ActionForward;

public class NoticeDetailAction implements Action {

	public ActionForward execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
		request.setCharacterEncoding("UTF-8");
		ActionForward forward = null;
		NoticeDAO noticedao = new NoticeDAO();
		NoticeBean noticedata = new NoticeBean();
		
		int num = Integer.parseInt(request.getParameter("num"));
		noticedata = noticedao.getDetail(num);
		if(noticedata ==null) {
			System.out.println("상세보기 실패");
			return null;
		}
		System.out.println("상세보기 성공");
		request.setAttribute("noticedata", noticedata);
		forward = new ActionForward();
		forward.setRedirect(false);
		forward.setPath("./NoticeView/notice_board_view.jsp");
		return forward;
		
	}
}
