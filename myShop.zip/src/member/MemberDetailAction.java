package member;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import controller.Action;
import controller.ActionForward;
import dao.MemberDAO;
import dto.MemberBean;

public class MemberDetailAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
		// TODO Auto-generated method stub
		ActionForward forward = new ActionForward();
		request.setCharacterEncoding("utf-8");

		MemberDAO dao = new MemberDAO();
		MemberBean dto = new MemberBean();
		dto.setMemberId(request.getParameter("memberId"));
		dto.setMemberPw(request.getParameter("memberPw"));
		dto.setMemberName(request.getParameter("memberName"));
		dto.setMemberAge(Integer.parseInt(request.getParameter("memberAge")));
		dto.setMemberAddress(request.getParameter("memberAddress"));
		dto.setMemberEmail(request.getParameter("memberEmail"));
		dto.setMemberPhone(request.getParameter("memberPhone"));
		
	
		boolean result = dao.update(dto);
		
		if(!result) {
			System.out.println("������Ʈ ����");
			forward.setRedirect(true);
			forward.setPath("MemberLogin.me");
			
		} else {
			forward.setRedirect(true);
			forward.setPath("MemberMain.me");
		}
	
		
		
		return forward;

	}

}
