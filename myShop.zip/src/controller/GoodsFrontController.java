package controller;

import javax.servlet.RequestDispatcher;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import goods.GoodsAddAction;
import goods.GoodsCartAddAction;
import goods.GoodsCartListAction;
import goods.GoodsCartQtyDownAction;
import goods.GoodsCartQtyUpAction;
import goods.GoodsCartRemoveAction;
import goods.GoodsListAction;
import goods.GoodsViewAction;



public class GoodsFrontController extends javax.servlet.http.HttpServlet implements javax.servlet.Servlet{
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) {
		doProcess(request,response);
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) {
		doProcess(request,response);
	}
	
	protected void doProcess(HttpServletRequest request, HttpServletResponse response) {
		String requestURI = request.getRequestURI();
		String contextPath = request.getContextPath();
		String command = requestURI.substring(contextPath.length());
		
		Action action = null;
		ActionForward forward = null;
		
		if(command.equals("/main.goods")) {
			forward = new ActionForward();
			forward.setRedirect(false);
			forward.setPath("./Goods/main.jsp");
		} else if(command.equals("/goodsList.goods")) {
			action = new GoodsListAction();
			try {
				forward = action.execute(request, response);
			} catch(Exception e) {
				e.printStackTrace();
			}
		} else if(command.equals("/goodsWrite.goods")) {
			forward = new ActionForward();
			forward.setRedirect(false);
			forward.setPath("./Goods/goodsWrite.jsp");
		} else if(command.equals("/goodsAddAction.goods")) {
			action = new GoodsAddAction();
			try {
				forward = action.execute(request, response);
			} catch(Exception e) {
				e.printStackTrace();
			}
		} else if(command.equals("/goodsView.goods")) {
			action = new GoodsViewAction();
			try {
				forward = action.execute(request, response);
			} catch(Exception e) {
				e.printStackTrace();
			}
		} else if(command.equals("/goodsCartRemove.goods")) {
			action = new GoodsCartRemoveAction();
			try {
				forward = action.execute(request, response);
			} catch(Exception e) {
				e.printStackTrace();
			}
		} else if(command.equals("/goodsCartQtyUp.goods")) {
			action = new GoodsCartQtyUpAction();
			try {
				forward = action.execute(request, response);
			} catch(Exception e) {
				e.printStackTrace();
			}
		} else if(command.equals("/goodsCartQtyDown.goods")) {
			action = new GoodsCartQtyDownAction();
			try {
				forward = action.execute(request, response);
			} catch(Exception e) {
				e.printStackTrace();
			}
		} else if(command.equals("/goodsCartList.goods")) {
			action = new GoodsCartListAction();
			try {
				forward = action.execute(request, response);
			} catch(Exception e) {
				e.printStackTrace();
			}
		} else if(command.equals("/goodsCartAdd.goods")) {
			action = new GoodsCartAddAction();
			try {
				forward = action.execute(request, response);
			} catch(Exception e) {
				e.printStackTrace();
			}
		}
		
		
		
		
		if(forward != null) {
			try {
				if(forward.isRedirect()){
				response.sendRedirect(forward.getPath());
				
			}else {
				RequestDispatcher dispatcher = request.getRequestDispatcher(forward.getPath());
				dispatcher.forward(request, response);
			}
		}catch(Exception e){
			e.printStackTrace();
		}
			
		}
	}
}
