package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;


import dto.MemberBean;

public class MemberDAO {

	Connection con = null;
	Connection conn = null;
	PreparedStatement pstmt = null;
	ResultSet rs = null;
	String sql = null;

	public Connection getConnection() throws Exception {

		String driver = "oracle.jdbc.driver.OracleDriver";
		String url = "jdbc:oracle:thin:@localhost:1521:XE";
		Class.forName(driver);
		conn = DriverManager.getConnection(url, "smrit", "oracle");

		return conn;

	}

	public int login(MemberBean dto) {

		int result = -1;

		try {
			con = getConnection();
			String sql = "select member_pw from member where member_id = ?";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, dto.getMemberId());
			rs = pstmt.executeQuery();

			if (rs.next()) {
				if (rs.getString("member_pw").equals(dto.getMemberPw())) {
					result = 1;
				} else {
					result = 0;
				}
			} else {
				result = -1;
			}

			System.out.println("LOGINRESULT: " + result);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			if (rs != null)
				try {
					rs.close();
				} catch (Exception e) {
				}
			if (pstmt != null)
				try {
					pstmt.close();
				} catch (Exception e) {
				}
			if (con != null)
				try {
					con.close();
				} catch (Exception e) {
				}
		}

		return result;
	}

	public boolean join(MemberBean dto) {
		boolean result = false;

		try {
			con = getConnection();
			sql = "insert into member (MEMBER_ID, MEMBER_PW, MEMBER_ADDRESS, MEMBER_NAME, MEMBER_PHONE, MEMBER_EMAIL,"
					+ " MEMBER_JUMIN, MEMBER_GENDER, MEMBER_AGE)" + " values (?,?,?,?,?,?,?,?,?)";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, dto.getMemberId());
			pstmt.setString(2, dto.getMemberPw());
			pstmt.setString(3, dto.getMemberAddress());
			pstmt.setString(4, dto.getMemberName());
			pstmt.setString(5, dto.getMemberPhone());
			pstmt.setString(6, dto.getMemberEmail());
			pstmt.setInt(7, dto.getMemberJumin());
			pstmt.setString(8, dto.getMemberGender());
			pstmt.setInt(9, dto.getMemberAge());

			int i = pstmt.executeUpdate();

			if (i == 0) {
				result = false;
			} else {
				result = true;
			}

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			if (pstmt != null)
				try {
					pstmt.close();
				} catch (Exception e) {
				}
			if (con != null)
				try {
					con.close();
				} catch (Exception e) {
				}
		}

		return result;
	}

	public List list() {
		List memberList = new ArrayList();
		try {
			con = getConnection();
			String sql = "select * from member";
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				MemberBean dto = new MemberBean();

				dto.setMemberId(rs.getString("member_id"));
				dto.setMemberPw(rs.getString("member_pw"));
				dto.setMemberName(rs.getString("member_name"));
				dto.setMemberAge(rs.getInt("member_age"));
				dto.setMemberGender(rs.getString("member_gender"));//
				dto.setMemberAddress(rs.getString("member_address")); //
				dto.setMemberJumin(rs.getInt("member_jumin"));//
				dto.setMemberPhone(rs.getString("member_phone"));//
				dto.setMemberEmail(rs.getString("member_email"));

				memberList.add(dto);

			}

			int i = pstmt.executeUpdate();
			System.out.println("LISTRESULT: " + i);

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			if (rs != null)
				try {
					rs.close();
				} catch (Exception e) {
				}
			if (pstmt != null)
				try {
					pstmt.close();
				} catch (Exception e) {
				}
			if (con != null)
				try {
					con.close();
				} catch (Exception e) {
				}
		}

		return memberList;
	}

	public void delete(String id) {
		try {
			con = getConnection();
			String sql = "delete from member where member_id = ?";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, id);

			int i = pstmt.executeUpdate();
			System.out.println("DELETERESULT: " + i);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			if (rs != null)
				try {
					rs.close();
				} catch (Exception e) {
				}
			if (pstmt != null)
				try {
					pstmt.close();
				} catch (Exception e) {
				}
			if (con != null)
				try {
					con.close();
				} catch (Exception e) {
				}
		}

	}

	public MemberBean info(String id) {

		MemberBean dto = new MemberBean();
		try {
			con = getConnection();
			String sql = "select * from member where member_id = ?";

			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, id);
			rs = pstmt.executeQuery();

			if (rs.next()) {
//				dto.setMemberAge(rs.getInt("member_age"));
//				dto.setMemberEmail(rs.getString("member_email"));
//				dto.setMemberGender(rs.getString("member_gender"));
//				dto.setMemberId(rs.getString("member_id"));
//				dto.setMemberName(rs.getString("member_name"));
//				dto.setMemberPw(rs.getString("member_pw"));
//				
				dto.setMemberId(rs.getString("member_id"));
				dto.setMemberPw(rs.getString("member_pw"));
				dto.setMemberName(rs.getString("member_name"));
				dto.setMemberAge(rs.getInt("member_age"));
				dto.setMemberGender(rs.getString("member_gender"));//
				dto.setMemberAddress(rs.getString("member_address")); //
				dto.setMemberJumin(rs.getInt("member_jumin"));//
				dto.setMemberPhone(rs.getString("member_phone"));//
				dto.setMemberEmail(rs.getString("member_email"));

			}
			int i = pstmt.executeUpdate();
			System.out.println("INFORESULT: " + i);

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			if (rs != null)
				try {
					rs.close();
				} catch (Exception e) {
				}
			if (pstmt != null)
				try {
					pstmt.close();
				} catch (Exception e) {
				}
			if (con != null)
				try {
					con.close();
				} catch (Exception e) {
				}
		}
		return dto;
	}

	public boolean update(MemberBean dto) {

		boolean result = false;
		try {
			con = getConnection();
			String sql = "update member set member_pw = ?, member_name = ?, member_age = ?,member_address = ?,"
					+ " member_email = ?, member_phone = ? where member_id = ?";

			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, dto.getMemberPw());
			pstmt.setString(2, dto.getMemberName());
			pstmt.setInt(3, dto.getMemberAge());
			pstmt.setString(4, dto.getMemberAddress());
			pstmt.setString(5, dto.getMemberEmail());
			pstmt.setString(6, dto.getMemberPhone());
			pstmt.setString(7, dto.getMemberId());

			int i = pstmt.executeUpdate();
			System.out.println("UPDATERESULT: " + i);

			if (i == 0) {
				result = false;
			} else {
				result = true;
			}

		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} finally {

			if (rs != null)
				try {
					rs.close();
				} catch (Exception e) {
				}
			if (pstmt != null)
				try {
					pstmt.close();
				} catch (Exception e) {
				}
			if (con != null)
				try {
					con.close();
				} catch (Exception e) {
				}
		}
		return result;

	}

	public boolean idCheck(MemberBean dto) {
		boolean result = false;
		try {
			con = getConnection();
			String sql = "select member_id from member where member_id = ?";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, dto.getMemberId());
			rs = pstmt.executeQuery();

			if (rs.next()) {
				if (rs.getString("member_id").equals(dto.getMemberId())) {
					result = true;
				} else {
					result = false;
				}
			}

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {

			if (rs != null)
				try {
					rs.close();
				} catch (Exception e) {
				}
			if (pstmt != null)
				try {
					pstmt.close();
				} catch (Exception e) {
				}
			if (con != null)
				try {
					con.close();
				} catch (Exception e) {
				}
		}

		return result;
	}
}
