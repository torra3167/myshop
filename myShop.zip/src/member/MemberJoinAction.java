package member;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import controller.Action;
import controller.ActionForward;
import dao.MemberDAO;

import dto.MemberBean;

public class MemberJoinAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("utf-8");
		ActionForward forward = new ActionForward();
		MemberBean dto = new MemberBean();
		MemberDAO dao = new MemberDAO();
		
		dto.setMemberId(request.getParameter("memberId"));
		dto.setMemberPw(request.getParameter("memberPw"));
		dto.setMemberName(request.getParameter("memberName"));
		dto.setMemberAge(Integer.parseInt(request.getParameter("memberAge")));
		dto.setMemberGender(request.getParameter("memberGender"));//
		dto.setMemberAddress(request.getParameter("memberAddress")); //
		dto.setMemberJumin(Integer.parseInt(request.getParameter("memberJumin1")));//
		dto.setMemberJumin(Integer.parseInt(request.getParameter("memberJumin2")));//
		dto.setMemberPhone(request.getParameter("memberPhone"));//
		dto.setMemberEmail(request.getParameter("memberEmail"));
	
		
	

		
		boolean result = dao.join(dto);
		
		if(!result) {
			System.out.println("ȸ����������");
			forward = null;
		} else {
			System.out.println("ȸ����������");
			forward.setRedirect(true);
			forward.setPath("MemberLogin.me");
		}
		
		
		
		return forward;

	}
	
}
