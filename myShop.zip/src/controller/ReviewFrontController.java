package controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import controller.Action;
import controller.ActionForward;
import review.ReviewAddAction;
import review.ReviewDeleteAction;
import review.ReviewDetailAction;
import review.ReviewListAction;
import review.ReviewModifyAction;
import review.ReviewModifyView;
import review.ReviewReplyAction;
import review.ReviewReplyView;



public class ReviewFrontController extends javax.servlet.http.HttpServlet implements javax.servlet.Servlet {

	protected void doProcess(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String RequestURI = request.getRequestURI();
		String ContextPath = request.getContextPath();
		String command = RequestURI.substring(ContextPath.length());
		ActionForward forward = null;
		Action action = null;

		if (command.equals("/ReviewList.review")) {
			action = new ReviewListAction();
			try {
				forward = action.execute(request, response);
			} catch (Exception e) {
				e.printStackTrace();
			}

		} else if (command.equals("/ReviewWrite.review")) {
			forward = new ActionForward();
			forward.setRedirect(false);
			forward.setPath("./ReviewView/review_board_write.jsp");

		} else if (command.equals("/ReviewAddAction.review")) {
			action = new ReviewAddAction();
			try {
				forward = action.execute(request, response);
			} catch (Exception e) {
				e.printStackTrace();
			}

		} else if (command.equals("/ReviewDetailAction.review")) {
			action = new ReviewDetailAction();
			System.out.println("ReviewDetailAction.review");
			try {
				forward = action.execute(request, response);
			} catch (Exception e) {
				e.printStackTrace();
			}

		} else if (command.equals("/ReviewReplyView.review")) {
			action = new ReviewReplyView();
			System.out.println("ReviewReplyView.review");
			try {
				forward = action.execute(request, response);
			} catch (Exception e) {
				e.printStackTrace();
			}

		} else if (command.equals("/ReviewReplyAction.review")) {
			action = new ReviewReplyAction();
			try {
				forward = action.execute(request, response);
			} catch (Exception e) {
				e.printStackTrace();
			}

		} else if (command.equals("/ReviewModify.review")) {
			action = new ReviewModifyView();
			try {
				forward = action.execute(request, response);
			} catch (Exception e) {
				e.printStackTrace();
			}

		} else if (command.equals("/ReviewModifyAction.review")) {
			action = new ReviewModifyAction();
			try {
				forward = action.execute(request, response);
			} catch (Exception e) {
				e.printStackTrace();
			}

		} else if (command.equals("/ReviewDelete.review")) {
			forward = new ActionForward();
			forward.setRedirect(false);
			forward.setPath("./ReviewView/review_board_delete.jsp");

		} else if (command.equals("/ReviewDeleteAction.review")) {
			action = new ReviewDeleteAction();
			try {
				forward = action.execute(request, response);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		if (forward != null) {
			try {
				if (forward.isRedirect()) {
					response.sendRedirect(forward.getPath());
				} else {
					RequestDispatcher dispatcher = request.getRequestDispatcher(forward.getPath());
					dispatcher.forward(request, response);
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		System.out.println("get");
		doProcess(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		System.out.println("post");
		doProcess(request, response);
	}
}
