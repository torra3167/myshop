package dto;

public class Goods {
	private int goodsNum;
	private String categoryId;
	private String goodsKind;
	private String goodsName;
	private int goodsPrice;
	private String goodsImage;
	private String goodsCountry;
	private String goodsSize;
	private String goodsColor;
	private String goodsContent;
	private int goodsReadcount;
	
	public int getGoodsNum() {
		return goodsNum;
	}
	public void setGoodsNum(int goodsNum) {
		this.goodsNum = goodsNum;
	}
	public String getCategoryId() {
		return categoryId;
	}
	public void setCategoryId(String categoryId) {
		this.categoryId = categoryId;
	}
	public String getGoodsKind() {
		return goodsKind;
	}
	public void setGoodsKind(String goodsKind) {
		this.goodsKind = goodsKind;
	}
	public String getGoodsName() {
		return goodsName;
	}
	public void setGoodsName(String goodsName) {
		this.goodsName = goodsName;
	}
	public int getGoodsPrice() {
		return goodsPrice;
	}
	public void setGoodsPrice(int goodsPrice) {
		this.goodsPrice = goodsPrice;
	}
	public String getGoodsImage() {
		return goodsImage;
	}
	public void setGoodsImage(String goodsImage) {
		this.goodsImage = goodsImage;
	}
	public String getGoodsCountry() {
		return goodsCountry;
	}
	public void setGoodsCountry(String goodsCountry) {
		this.goodsCountry = goodsCountry;
	}
	public String getGoodsSize() {
		return goodsSize;
	}
	public void setGoodsSize(String goodsSize) {
		this.goodsSize = goodsSize;
	}
	public String getGoodsColor() {
		return goodsColor;
	}
	public void setGoodsColor(String goodsColor) {
		this.goodsColor = goodsColor;
	}
	public String getGoodsContent() {
		return goodsContent;
	}
	public void setGoodsContent(String goodsContent) {
		this.goodsContent = goodsContent;
	}
	public int getGoodsReadcount() {
		return goodsReadcount;
	}
	public void setGoodsReadcount(int goodsReadcount) {
		this.goodsReadcount = goodsReadcount;
	}
	

}
