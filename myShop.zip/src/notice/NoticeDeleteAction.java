package notice;

import java.io.PrintWriter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import controller.Action;
import controller.ActionForward;
import dao.NoticeDAO;

public class NoticeDeleteAction implements Action {

	public ActionForward execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
		ActionForward forward = new ActionForward();
		
		request.setCharacterEncoding("utf-8");
		int num = Integer.parseInt(request.getParameter("num"));
		String notice_pass = request.getParameter("NOTICE_PASS");
		NoticeDAO noticedao = new NoticeDAO();
		boolean usercheck = noticedao.isNoticeWriter(num,notice_pass);
		if (usercheck == false) {
			response.setContentType("text/html;charset=utf-8");
			PrintWriter out = response.getWriter();
			out.println("<script>");
			out.println("alert('삭제할 권한이 없습니다.');");
			out.println("location.href='./NoticeList.notice';");
			out.println("</script>");
			out.close();
			return null;
		}
		int result = noticedao.noticeDelete(num);
		if (result == 0) {
			System.out.println("게시판 삭제 실패");
			return null;
		}
		System.out.println("게시판 삭제 성공");
		forward.setRedirect(true);
		forward.setPath("./NoticeList.notice");
		return forward;
	}
}
