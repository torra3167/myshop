package member;

import java.io.PrintWriter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import controller.Action;
import controller.ActionForward;
import dao.MemberDAO;
import dto.MemberBean;

public class MemberLoginAction implements Action {

	
		@Override
		public ActionForward execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
			// TODO Auto-generated method stub
			ActionForward forward = new ActionForward();
			HttpSession session = request.getSession();
			MemberBean dto = new MemberBean();
			MemberDAO dao = new MemberDAO();
			request.setCharacterEncoding("utf-8");

			dto.setMemberId(request.getParameter("memberId"));
			dto.setMemberPw(request.getParameter("memberPw"));
			
			int result = dao.login(dto);
			
			if(result == 0) {
				response.setContentType("text/html;charset=utf-8");
				PrintWriter pw = response.getWriter();
				pw.println("<script>");
				pw.println("alert('��й�ȣ�� Ʋ�Ⱦ�')");
				pw.println("location.href='MemberLogin.me'");
				pw.println("</script>");
				pw.close();

			} else if(result == -1) {
				
				response.setContentType("text/html;charset=utf-8");
				PrintWriter pw = response.getWriter();
				pw.println("<script>");
				pw.println("alert('���̵� ���°�?')");
				pw.println("location.href='MemberLogin.me'");
				pw.println("</script>");
				
				
				pw.close();
				
			} else {
				System.out.println("�α��μ���");
				session.setAttribute("ID", dto.getMemberId());
				forward.setRedirect(false);
				forward.setPath("MemberView/main.jsp");
			}
			
			
			
			
			return forward;
	}

}
