package review;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.oreilly.servlet.MultipartRequest;
import com.oreilly.servlet.multipart.DefaultFileRenamePolicy;

import controller.Action;
import controller.ActionForward;
import dao.ReviewDAO;
import dto.ReviewBean;

public class ReviewAddAction implements Action {

	public ActionForward execute(HttpServletRequest request, HttpServletResponse response) throws Exception {

		request.setCharacterEncoding("utf-8");

		ActionForward forward = new ActionForward();
		ReviewDAO reviewdao = new ReviewDAO();
		ReviewBean reviewdata = new ReviewBean();
		System.out.println(request.getRealPath("/"));
		String realFolder = request.getRealPath("/ReviewUpload");
		int fileSize = 5 * 1024 * 1024; 
		int i = 0;
		 
		MultipartRequest multi = null;
		multi = new MultipartRequest(request, realFolder, fileSize, "UTF-8", new DefaultFileRenamePolicy()); 
		reviewdata.setReviewPw(multi.getParameter("REVIEW_PASS"));
		reviewdata.setReviewName(multi.getParameter("REVIEW_NAME"));
		reviewdata.setReviewSubject(multi.getParameter("REVIEW_SUBJECT"));
		reviewdata.setReviewContent(multi.getParameter("REVIEW_CONTENT"));
		reviewdata.setReviewFile(multi.getFilesystemName((String) multi.getFileNames().nextElement()));
		
		i = reviewdao.reviewInsert(reviewdata);
		
		if (i > 0)
			System.out.println("게시글 저장");
		else
			System.out.println("게시글 저장 실패");
		forward.setRedirect(true);
		forward.setPath("./ReviewList.review");

		return forward;
	}
}
