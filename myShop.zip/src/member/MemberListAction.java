package member;

import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import controller.Action;
import controller.ActionForward;
import dao.MemberDAO;

public class MemberListAction implements Action {

	
		@Override
		public ActionForward execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
			// TODO Auto-generated method stub
			ActionForward forward = new ActionForward();
			request.setCharacterEncoding("utf-8");

			HttpSession session = request.getSession();
			String sessionId = (String)session.getAttribute("ID");
			MemberDAO dao = new MemberDAO();
			List memberList = new ArrayList();
			
			memberList = dao.list();
			
			if(memberList == null) {
				System.out.println("����Ʈ��������");
				forward.setRedirect(false);
				forward.setPath("MemberMain.me");
				
			} else if(!sessionId.equals("admin")) {
				response.setContentType("text/html;charset=utf-8");
				PrintWriter pw = response.getWriter();
				pw.println("<script>");
				pw.println("alert('�����ڰ� �ƴϿ���')");
				pw.println("location.href='MemberMain.me'");
				pw.println("</script>");
				
			} else {
				System.out.println("����Ʈ���� ����");
				request.setAttribute("memberList", memberList);
				forward.setRedirect(false);
				forward.setPath("MemberView/member_list.jsp");
			}
			
		
			
			return forward;
		}

	}
