package review;

import java.io.PrintWriter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import controller.Action;
import controller.ActionForward;
import dao.ReviewDAO;

public class ReviewDeleteAction implements Action {

	public ActionForward execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
		ActionForward forward = new ActionForward();
		request.setCharacterEncoding("utf-8");
		int num = Integer.parseInt(request.getParameter("num"));
		String review_pass = request.getParameter("REVIEW_PASS");
		ReviewDAO reviewdao = new ReviewDAO();
		boolean usercheck = reviewdao.isReviewWriter(num, review_pass);
		if (usercheck == false) {
			response.setContentType("text/html;charset=utf-8");
			PrintWriter out = response.getWriter();
			out.println("<script>");
			out.println("alert('삭제할 권한이 없습니다.');");
			out.println("location.href='./ReviewList.review';");
			out.println("</script>");
			out.close();
			return null;
		}
		int result = reviewdao.reviewDelete(num);
		if (result == 0) {
			System.out.println("게시판 삭제 실패");
			return null;
		}
		System.out.println("게시판 삭제 성공");
		forward.setRedirect(true);
		forward.setPath("./ReviewList.review");
		return forward;
	}
}
