package member;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import controller.Action;
import controller.ActionForward;
import dao.MemberDAO;

public class MemberDeleteAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("utf-8");
		ActionForward forward = new ActionForward();
		MemberDAO dao = new MemberDAO();
		String id = request.getParameter("id");
		
		dao.delete(id);
		forward.setRedirect(true);
		forward.setPath("MemberLogin.me");
		
		return forward;
	}

}
