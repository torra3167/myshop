package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import dto.ReviewBean;
public class ReviewDAO {

	Connection conn = null;
	Connection con = null;
	PreparedStatement pstmt = null;
	String sql = null;
	ResultSet rs = null;

	public Connection getConnection() throws Exception {
		String driver = "oracle.jdbc.driver.OracleDriver";
		String url = "jdbc:oracle:thin:@localhost:1521:XE";
		Class.forName(driver);
		conn = DriverManager.getConnection(url, "smrit", "oracle");
		return conn;
	}

	public int reviewInsert(ReviewBean reviewdata) {
		int i = 0;
		int num = 0;
		try {
			con = getConnection();
			sql = "select max(review_num) from review";
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			if (rs.next()) {
				num = rs.getInt(1) + 1;
			} else {
				num = 1;
			}
			sql = "insert into review(review_num,review_name,review_pw,review_subject,review_content,review_file,review_re_ref,review_re_lev,review_re_seq,review_readcount,review_date)"
					+ " values(?,?,?,?,?,?,?,?,?,?,sysdate)";
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, num);
			pstmt.setString(2, reviewdata.getReviewName());
			pstmt.setString(3, reviewdata.getReviewPw());
			pstmt.setString(4, reviewdata.getReviewSubject());
			pstmt.setString(5, reviewdata.getReviewContent());
			pstmt.setString(6, reviewdata.getReviewFile());
			pstmt.setInt(7, num); // BOARD_REF 부모글번호
			pstmt.setInt(8, 0);
			pstmt.setInt(9, 0);
			pstmt.setInt(10, 0);
			i = pstmt.executeUpdate();
			System.out.println(i + "개가 저장되었습니다.");
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (rs != null)
				try {
					rs.close();
				} catch (SQLException ex) {
				}
			if (pstmt != null)
				try {
					pstmt.close();
				} catch (SQLException ex) {
				}
			if (con != null)
				try {
					con.close();
				} catch (SQLException ex) {
				}
		}
		return i;
	}

	public int getListCount() {
		int x = 0;
		try {
			con = getConnection();
			pstmt = con.prepareStatement("select count(*) from review");
			rs = pstmt.executeQuery();
			if (rs.next()) {
				x = rs.getInt(1);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (rs != null)
				try {
					rs.close();
				} catch (SQLException ex) {
				}
			if (pstmt != null)
				try {
					pstmt.close();
				} catch (SQLException ex) {
				}
			if (con != null)
				try {
					con.close();
				} catch (SQLException ex) {
				}
		}
		return x;
	}

	public List getReviewList(int page, int limit) {
		List list = new ArrayList();
		try {
			con = getConnection();
			sql = "select * from "
					+ "(select rownum rnum,review_num,review_name,review_pw,review_subject, review_content,review_file ,review_re_ref,review_re_lev,review_re_seq,review_readcount,review_date "
					+ "    from (select * from review order by review_re_ref desc,review_re_seq asc)" + ")"
					+ "where rnum >=? and  rnum <= ?";
			int startRow = (page - 1) * limit + 1;
			int endRow = startRow + limit - 1;
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, startRow);
			pstmt.setInt(2, endRow);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				ReviewBean reviewdata = new ReviewBean();
				reviewdata.setReviewNum(rs.getInt("review_num"));
				reviewdata.setReviewName(rs.getString("review_name"));
				reviewdata.setReviewPw(rs.getString("review_pw"));
				reviewdata.setReviewSubject(rs.getString("review_subject"));
				reviewdata.setReviewContent(rs.getString("review_content"));
				reviewdata.setReviewFile(rs.getString("review_file"));
				reviewdata.setReviewReRef(rs.getInt("review_re_ref"));
				reviewdata.setReviewReLev(rs.getInt("review_re_lev"));
				reviewdata.setReviewReSeq(rs.getInt("review_re_seq"));
				reviewdata.setReviewReadcount(rs.getInt("review_readcount"));
				reviewdata.setReviewDate(rs.getDate("review_date"));
				list.add(reviewdata);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (rs != null)
				try {
					rs.close();
				} catch (SQLException ex) {
				}
			if (pstmt != null)
				try {
					pstmt.close();
				} catch (SQLException ex) {
				}
			if (con != null)
				try {
					con.close();
				} catch (SQLException ex) {
				}
		}
		return list;
	}

	public ReviewBean getDetail(int num) {
		ReviewBean reviewdata = null;
		try {
			con = getConnection();
			sql = "update review set review_readcount=review_readcount+1 where review_num=?";
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, num);
			int result = pstmt.executeUpdate();
			System.out.println(result + "개가 수정되었습니다.");
			sql = "select * from review where review_num=?";
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, num);
			rs = pstmt.executeQuery();
			if (rs.next()) {
				reviewdata = new ReviewBean();
				reviewdata.setReviewNum(rs.getInt("review_Num"));
				reviewdata.setReviewName(rs.getString("review_name"));
				reviewdata.setReviewSubject(rs.getString("review_subject"));
				reviewdata.setReviewContent(rs.getString("review_content"));
				reviewdata.setReviewFile(rs.getString("review_file"));
				reviewdata.setReviewReRef(rs.getInt("review_re_ref"));
				reviewdata.setReviewReLev(rs.getInt("review_re_lev"));
				reviewdata.setReviewReSeq(rs.getInt("review_re_seq"));
				reviewdata.setReviewReadcount(rs.getInt("review_readcount"));
				reviewdata.setReviewDate(rs.getDate("review_date"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (rs != null)
				try {
					rs.close();
				} catch (SQLException ex) {
				}
			if (pstmt != null)
				try {
					pstmt.close();
				} catch (SQLException ex) {
				}
			if (con != null)
				try {
					con.close();
				} catch (SQLException ex) {
				}
		}
		return reviewdata;
	}

	public int reviewReply(ReviewBean reviewdata) {
		int i = 0;
		try {
			con = getConnection();
			sql = "select max(review_num)+1 from review";
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			int maxnum = 0;
			if (rs.next())
				maxnum = rs.getInt(1);
			else
				maxnum = 1;
			i = maxnum;// 자기 글 번호
			sql = "update review set review_re_seq=review_re_seq+1 where review_re_ref=? and review_re_seq>?";
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, reviewdata.getReviewReRef());
			pstmt.setInt(2, reviewdata.getReviewReSeq());
			int result = pstmt.executeUpdate();

			int re_seq = reviewdata.getReviewReSeq() + 1;
			int re_lev = reviewdata.getReviewReLev() + 1;

			sql = "insert into review (review_num,review_name,review_pw,review_subject,review_content,"
					+ "review_file,review_re_ref,review_re_lev,review_re_seq,review_readcount,review_date)"
					+ " values(?,?,?,?,?,?,?,?,?,?,sysdate)";
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, maxnum);
			pstmt.setString(2, reviewdata.getReviewName());
			pstmt.setString(3, reviewdata.getReviewPw());
			pstmt.setString(4, reviewdata.getReviewSubject());
			pstmt.setString(5, reviewdata.getReviewContent());
			pstmt.setString(6, "");
			pstmt.setInt(7, reviewdata.getReviewReRef());
			pstmt.setInt(8, re_lev);
			pstmt.setInt(9, re_seq);
			pstmt.setInt(10, 0);
			pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (rs != null)
				try {
					rs.close();
				} catch (SQLException ex) {
				}
			if (pstmt != null)
				try {
					pstmt.close();
				} catch (SQLException ex) {
				}
			if (con != null)
				try {
					con.close();
				} catch (SQLException ex) {
				}
		}
		return i;
	}

	public boolean isReviewWriter(int num, String pw) {
		try {
			sql = "select review_pw from review where review_num =?";
			con = getConnection();
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, num);
			rs = pstmt.executeQuery();
			rs.next();
			if (pw.equals(rs.getString(1))) {
				return true;
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (rs != null)
				try {
					rs.close();
				} catch (SQLException ex) {
				}
			if (pstmt != null)
				try {
					pstmt.close();
				} catch (SQLException ex) {
				}
			if (con != null)
				try {
					con.close();
				} catch (SQLException ex) {
				}
		}
		return false;
	}

	public int reviewModify(ReviewBean modifyreview) {
		int result = 0;
		sql = "update review set review_subject=?,review_content=? where review_num=?";
		try {
			con = getConnection();
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, modifyreview.getReviewSubject());
			pstmt.setString(2, modifyreview.getReviewContent());
			pstmt.setInt(3, modifyreview.getReviewNum());
			result = pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (rs != null)
				try {
					rs.close();
				} catch (SQLException ex) {
				}
			if (pstmt != null)
				try {
					pstmt.close();
				} catch (SQLException ex) {
				}
			if (con != null)
				try {
					con.close();
				} catch (SQLException ex) {
				}
		}
		return result;
	}

	public int reviewDelete(int num) {
		int result = 0;
		sql = "delete from review where review_num=?";
		try {
			con = getConnection();
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, num);
			result = pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (pstmt != null)
				try {
					pstmt.close();
				} catch (SQLException ex) {
				}
			if (con != null)
				try {
					con.close();
				} catch (SQLException ex) {
				}
		}
		return result;
	}
}
