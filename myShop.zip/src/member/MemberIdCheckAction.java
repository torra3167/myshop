package member;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import controller.Action;
import controller.ActionForward;
import dao.MemberDAO;

import dto.MemberBean;

public class MemberIdCheckAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("utf-8");

		ActionForward forward = new ActionForward();
		String id = request.getParameter("memberId");
		System.out.println(id);
		MemberDAO dao = new MemberDAO();
		MemberBean dto = new MemberBean();

		if (id == null) {
			System.out.println("id�� �޾ƿ������");
			forward.setRedirect(true);
			forward.setPath("MemberLogin.me");

		} else {
			dto.setMemberId(id);
			boolean result = dao.idCheck(dto);

			if (!result) {
				System.out.println("���̵��ߺ�Ȯ�ν���");
//				request.setAttribute("chk", 0);
				request.setAttribute("chk", dto.getMemberId());

			} else {
				request.setAttribute("id", dto.getMemberId());
//				request.setAttribute("chk", 1);

			}

			forward.setRedirect(false);
			forward.setPath("MemberView/member_idchk.jsp");
		}

		return forward;
	}
}
