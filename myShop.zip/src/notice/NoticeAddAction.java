package notice;

import java.util.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.oreilly.servlet.MultipartRequest;
import com.oreilly.servlet.multipart.DefaultFileRenamePolicy;

import controller.Action;
import controller.ActionForward;
import dao.NoticeDAO;
import dto.NoticeBean;

public class NoticeAddAction implements Action {

	public ActionForward execute(HttpServletRequest request, HttpServletResponse response) throws Exception {

		request.setCharacterEncoding("utf-8");

		ActionForward forward = new ActionForward();
		NoticeDAO noticedao = new NoticeDAO();
		NoticeBean noticedata = new NoticeBean();
		System.out.println(request.getRealPath("/"));
		String realFolder = request.getRealPath("/NoticeUpload");
		int fileSize = 5 * 1024 * 1024;
		int i = 0;

		MultipartRequest multi = null;
		multi = new MultipartRequest(request, realFolder, fileSize, "UTF-8", new DefaultFileRenamePolicy());
		noticedata.setNoticePw(multi.getParameter("NOTICE_PASS"));
		noticedata.setNoticeSubject(multi.getParameter("NOTICE_SUBJECT"));
		noticedata.setNoticeContent(multi.getParameter("NOTICE_CONTENT"));
		noticedata.setNoticeFile(multi.getFilesystemName((String) multi.getFileNames().nextElement()));
		
		i = noticedao.noticeInsert(noticedata);

		if (i > 0)
			System.out.println("게시글 저장");
		else
			System.out.println("게시글 저장 실패");
		forward.setRedirect(true);
		forward.setPath("./NoticeList.notice");

		return forward;
	}
}
