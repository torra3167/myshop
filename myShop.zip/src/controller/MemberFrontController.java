package controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import controller.Action;
import controller.ActionForward;
import member.MemberDeleteAction;
import member.MemberDetailAction;
import member.MemberIdCheckAction;
import member.MemberInfoAction;
import member.MemberJoinAction;
import member.MemberListAction;
import member.MemberLoginAction;
import member.MemberLogoutAction;
import member.MemberUpdateAction;

public class MemberFrontController extends javax.servlet.http.HttpServlet implements javax.servlet.Servlet {
	
	protected void doProcess(HttpServletRequest request, HttpServletResponse response) {
//		System.out.println("MemberFrontController");
		String requestURI = request.getRequestURI();
		String contextPath = request.getContextPath();
		String cmd = requestURI.substring(contextPath.length());
		Action action = null;
		ActionForward forward = null;
		
		
		if(cmd.equals("/MemberLogin.me")) {
			forward = new ActionForward();
			forward.setRedirect(false);
			forward.setPath("MemberView/loginForm.jsp");
			
		} else if(cmd.equals("/MemberJoin.me")) {
			forward = new ActionForward();
			forward.setRedirect(false);
			forward.setPath("MemberView/joinForm.jsp");
			
		} else if(cmd.equals("/MemberJoinAction.me")) {
			action = new MemberJoinAction();
			try {
				forward = action.execute(request, response);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		} else if(cmd.equals("/MemberLoginAction.me")) {
			action = new MemberLoginAction();
			try {
				forward = action.execute(request, response);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		} else if(cmd.equals("/MemberLogoutAction.me")) {
			action = new MemberLogoutAction();
			try {
				forward = action.execute(request, response);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		} else if(cmd.equals("/MemberListAction.me")) {
			action = new MemberListAction();
			try {
				forward = action.execute(request, response);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		} else if(cmd.equals("/MemberInfoAction.me")) {
			action = new MemberInfoAction();
			try {
				forward = action.execute(request, response);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		} else if(cmd.equals("/MemberDeleteAction.me")) {
			action = new MemberDeleteAction();
			try {
				forward = action.execute(request, response);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		} else if(cmd.equals("/MemberMain.me")) {
			forward = new ActionForward();
			forward.setRedirect(false);
			forward.setPath("MemberView/main.jsp");
			
		} else if(cmd.equals("/MemberDetailAction.me")) {
			action = new MemberDetailAction();
			System.out.println(request.getParameter("id"));
			try {
				forward = action.execute(request, response);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		} else if(cmd.equals("/MemberInfoAction.me")) {
			action = new MemberInfoAction();
			try {
				forward = action.execute(request, response);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		} else if(cmd.equals("/MemberUpdateAction.me")) {
			action = new MemberUpdateAction();
			try {
				forward = action.execute(request, response);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		} else if(cmd.equals("/MemberIdCheckAction.me")) {
			action = new MemberIdCheckAction();
			try {
				forward = action.execute(request, response);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		
		
		
		
		if(forward != null) {
			if(forward.isRedirect()) {
				try {
					response.sendRedirect(forward.getPath());
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			} else {
				try {
					RequestDispatcher rdp = request.getRequestDispatcher(forward.getPath());
					rdp.forward(request, response);
				} catch (ServletException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) {
		System.out.println("POST");
		doProcess(request, response);
	}
	protected void doGet(HttpServletRequest request, HttpServletResponse response) {
		System.out.println("GET");
		doProcess(request, response);
	}
}
