package review;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import controller.Action;
import controller.ActionForward;
import dao.ReviewDAO;
import dto.ReviewBean;

public class ReviewReplyAction implements Action {

	public ActionForward execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
		request.setCharacterEncoding("utf-8");
		ActionForward forward = new ActionForward();
		ReviewDAO reviewdao = new ReviewDAO();
		ReviewBean reviewdata = new ReviewBean();
		reviewdata.setReviewNum(Integer.parseInt(request.getParameter("REVIEW_NUM")));
		reviewdata.setReviewName(request.getParameter("REVIEW_NAME"));
		reviewdata.setReviewPw(request.getParameter("REVIEW_PASS"));
		reviewdata.setReviewSubject(request.getParameter("REVIEW_SUBJECT"));
		reviewdata.setReviewContent(request.getParameter("REVIEW_CONTENT"));
		reviewdata.setReviewReRef(Integer.parseInt(request.getParameter("REVIEW_RE_REF")));
		reviewdata.setReviewReLev(Integer.parseInt(request.getParameter("REVIEW_RE_LEV")));
		reviewdata.setReviewReSeq(Integer.parseInt(request.getParameter("REVIEW_RE_SEQ")));
		int result = reviewdao.reviewReply(reviewdata);
		if (result == 0) {
			System.out.println("답장 실패");
			return null;
		}
		System.out.println("답장 완료");

		forward.setRedirect(true);
		forward.setPath("./ReviewDetailAction.review?num=" + result);
		return forward;
	}
}
