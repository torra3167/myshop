package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import dto.Goods;

public class GoodsDAO {
	Connection conn = null;
	Connection con = null;
	PreparedStatement pstmt = null;
	ResultSet rs = null;
	String sql = null;
	public Connection getConnection() throws Exception{
		String driver = "oracle.jdbc.driver.OracleDriver";
		String url = "jdbc:oracle:thin:@localhost:1521:XE";
		Class.forName(driver);
		conn = DriverManager.getConnection(url, "smrit", "oracle");
		return conn;
	}
	
	public int goodsInsert(Goods Goods) {
		int result = 0;
		int num = 0;
		try {
			con = getConnection();
			sql = "select max(goods_num) from goods";
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			if(rs.next()) {
				num = rs.getInt(1) + 1;
			} else {
				num = 1;
			}
			sql = "insert into goods(goods_num, category_id, goods_kind, goods_name,"
					+ " goods_price, goods_image, goods_country, goods_size, goods_color,"
					+ " goods_content, goods_readcount) values(?,?,?,?,?,?,?,?,?,?,0)";
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, num);
			pstmt.setString(2, Goods.getCategoryId());
			pstmt.setString(3, Goods.getGoodsKind());
			pstmt.setString(4, Goods.getGoodsName());
			pstmt.setInt(5, Goods.getGoodsPrice());
			pstmt.setString(6, Goods.getGoodsImage());
			pstmt.setString(7, Goods.getGoodsCountry());
			pstmt.setString(8, Goods.getGoodsSize());
			pstmt.setString(9, Goods.getGoodsColor());
			pstmt.setString(10, Goods.getGoodsContent());
			result = pstmt.executeUpdate();
		} catch(Exception e) {
			e.printStackTrace();
		} finally {
			if(rs!=null) try {rs.close();} catch(SQLException ex) {}
			if(pstmt!=null) try {pstmt.close();} catch(SQLException ex) {}
			if(con!=null) try {con.close();} catch(SQLException ex) {}
		}
		return result;
	}

	public List getGoodss() {
		List goodss = new ArrayList();
		try {
			con = getConnection();
			sql = "select * from goods";
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			while(rs.next()) {
				Goods goods = new Goods();
				goods.setGoodsNum(rs.getInt("goods_Num"));
				goods.setCategoryId(rs.getString("category_Id"));
				goods.setGoodsKind(rs.getString("goods_kind"));
				goods.setGoodsName(rs.getString("goods_name"));
				goods.setGoodsPrice(rs.getInt("goods_price"));
				goods.setGoodsImage(rs.getString("goods_image"));
				goods.setGoodsCountry(rs.getString("goods_country"));
				goods.setGoodsSize(rs.getString("goods_size"));
				goods.setGoodsColor(rs.getString("goods_color"));
				goods.setGoodsContent(rs.getString("goods_content"));
				goods.setGoodsReadcount(rs.getInt("goods_readcount"));
				goodss.add(goods);
			} 
		} catch(Exception e) {
				e.printStackTrace();
		}
		return goodss;
		
	}

	public Goods getGoods(String id) {
		Goods goods = new Goods();
		try {
			con = getConnection();
			sql = "update goods set goods_readcount = goods_readcount + 1 where goods_num = ?";
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, Integer.parseInt(id));
			int result = pstmt.executeUpdate();
			System.out.println(result + "개가 수정");
			
			sql = "select * from goods where goods_num = ?";
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, Integer.parseInt(id));
			rs = pstmt.executeQuery();
			if(rs.next()) {
				goods.setGoodsNum(rs.getInt("goods_Num"));
				goods.setCategoryId(rs.getString("category_Id"));
				goods.setGoodsKind(rs.getString("goods_kind"));
				goods.setGoodsName(rs.getString("goods_name"));
				goods.setGoodsPrice(rs.getInt("goods_price"));
				goods.setGoodsImage(rs.getString("goods_image"));
				goods.setGoodsCountry(rs.getString("goods_country"));
				goods.setGoodsSize(rs.getString("goods_size"));
				goods.setGoodsColor(rs.getString("goods_color"));
				goods.setGoodsContent(rs.getString("goods_content"));
				goods.setGoodsReadcount(rs.getInt("goods_readcount"));
			}
			
		} catch(Exception e) {
			e.printStackTrace();
		}
		
		return goods;
	}
}