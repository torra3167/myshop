package goods;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import controller.Action;
import controller.ActionForward;
import dao.GoodsDAO;

public class GoodsListAction implements Action{
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
		ActionForward forward = new ActionForward();
		GoodsDAO goodsDao = new GoodsDAO();
		List goodss = goodsDao.getGoodss();
		request.setAttribute("goodss", goodss);
		
		Cookie[] cookies = request.getCookies();
		List<String> images = new ArrayList<String>();
		if(cookies != null) {
			for(int i = 0; i<cookies.length; i++) {
				if(cookies[i].getName().startsWith("image")) {
					images.add(cookies[i].getValue());
				}
			}
		}
		
		request.setAttribute("images", images);
		forward.setRedirect(false);
		forward.setPath("./Goods/goodsList.jsp");
		return forward;
	}

}
